import type {Metadata} from 'next';
import { Inter, Oswald } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' });
const oswald = Oswald({ subsets: ['latin'], variable: '--font-display' });

export const metadata: Metadata = {
  title: 'Burger O\'Clock | Bigger, Juicier, Better Burgers',
  description: 'A popular fast-food chain in Karachi known for its juicy burgers, crispy fried items, and quick service.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${inter.variable} ${oswald.variable} scroll-smooth`}>
      <body className="font-sans bg-stone-50 text-stone-900 antialiased" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
