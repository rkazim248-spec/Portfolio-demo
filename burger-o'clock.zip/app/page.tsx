'use client';

import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import MenuHighlights from '@/components/MenuHighlights';
import Deals from '@/components/Deals';
import About from '@/components/About';
import Gallery from '@/components/Gallery';
import Reviews from '@/components/Reviews';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import { Providers } from '@/components/Providers';
import CartDrawer from '@/components/CartDrawer';

export default function Home() {
  return (
    <Providers>
      <main className="min-h-screen bg-stone-50">
        <Navbar />
        <Hero />
        <MenuHighlights />
        <Deals />
        <About />
        <Gallery />
        <Reviews />
        <Contact />
        <Footer />
        <CartDrawer />
      </main>
    </Providers>
  );
}
