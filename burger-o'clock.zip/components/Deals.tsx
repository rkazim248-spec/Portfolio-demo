import { motion } from 'motion/react';
import Image from 'next/image';
import { Clock, Zap } from 'lucide-react';
import { useCart } from '@/context/CartContext';

export default function Deals() {
  const { addToCart } = useCart();

  return (
    <section id="deals" className="py-24 bg-red-600 text-white overflow-hidden relative">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Left Content */}
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 bg-black/20 px-4 py-2 rounded-full text-sm font-bold uppercase tracking-widest mb-6 backdrop-blur-sm">
                <Zap size={16} className="text-yellow-400" />
                Limited Time Offers
              </div>
              <h2 className="font-display text-5xl md:text-7xl font-black uppercase tracking-tighter leading-[0.9] mb-6">
                Midnight <br />
                <span className="text-black">Cravings?</span>
              </h2>
              <p className="text-white/90 text-lg md:text-xl mb-8 max-w-lg">
                We&apos;re open late! Grab our special Midnight Combo and satisfy your hunger. Available every day from 10 PM to closing.
              </p>
              
              <div className="bg-black/20 backdrop-blur-md rounded-2xl p-6 border border-white/10 mb-8">
                <h3 className="font-display text-2xl font-bold uppercase mb-2">The Night Owl Combo</h3>
                <ul className="space-y-2 mb-4 text-white/80">
                  <li>• 2x Mighty Zinger Burgers</li>
                  <li>• 1x Large Loaded Fries</li>
                  <li>• 2x Regular Drinks</li>
                </ul>
                <div className="flex items-end gap-4">
                  <span className="text-4xl font-black">PKR 1,999</span>
                  <span className="text-lg line-through text-white/50 mb-1">PKR 2,500</span>
                </div>
              </div>

              <button
                onClick={() => addToCart({
                  id: 'deal-night-owl',
                  name: 'The Night Owl Combo',
                  price: 1999,
                  image: 'https://images.unsplash.com/photo-1615719413546-198b25453f85?q=80&w=800&auto=format&fit=crop'
                })}
                className="inline-flex items-center justify-center bg-black hover:bg-stone-900 text-white px-8 py-4 rounded-full font-bold uppercase tracking-wider text-lg transition-transform hover:scale-105 shadow-xl"
              >
                Add to Cart
              </button>
            </motion.div>
          </div>

          {/* Right Image */}
          <div className="lg:w-1/2 relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
              whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, type: "spring" }}
              className="relative z-10"
            >
              <div className="aspect-square relative rounded-full overflow-hidden border-8 border-white/20 shadow-2xl">
                <Image
                  src="https://images.unsplash.com/photo-1615719413546-198b25453f85?q=80&w=800&auto=format&fit=crop"
                  alt="Midnight Combo Meal"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              
              {/* Floating Badge */}
              <motion.div 
                animate={{ y: [-10, 10, -10] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                className="absolute -bottom-6 -right-6 bg-yellow-400 text-black w-32 h-32 rounded-full flex flex-col items-center justify-center shadow-xl border-4 border-red-600 transform rotate-12"
              >
                <span className="font-display font-black text-3xl leading-none">SAVE</span>
                <span className="font-bold text-xl">20%</span>
              </motion.div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
