import { motion } from 'motion/react';
import Image from 'next/image';
import { useCart } from '@/context/CartContext';

const menuItems = [
  {
    id: 1,
    name: 'Mighty Zinger Burger',
    description: 'Double crispy chicken fillet, cheese, lettuce, and our signature spicy sauce.',
    price: 950,
    image: 'https://images.unsplash.com/photo-1610440042657-612c34d95e9f?q=80&w=800&auto=format&fit=crop',
    popular: true,
  },
  {
    id: 2,
    name: 'Chicken Biryani',
    description: 'Authentic Pakistani chicken biryani, basmati rice, rich spices, tender chicken.',
    price: 650,
    image: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?q=80&w=800&auto=format&fit=crop',
    popular: true,
  },
  {
    id: 3,
    name: 'BBQ Platter',
    description: 'Pakistani BBQ platter with seekh kebab, malai boti, grilled chicken, and naan.',
    price: 1450,
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=800&auto=format&fit=crop',
    popular: false,
  },
  {
    id: 4,
    name: 'Loaded Fries',
    description: 'Crispy fries topped with melted cheese, jalapeños, and grilled chicken chunks.',
    price: 650,
    image: 'https://images.unsplash.com/photo-1576107232684-1279f390859f?q=80&w=800&auto=format&fit=crop',
    popular: true,
  },
  {
    id: 5,
    name: 'Chicken Wings',
    description: '6 pieces of crispy wings tossed in your choice of BBQ or Buffalo sauce.',
    price: 550,
    image: 'https://images.unsplash.com/photo-1608039829572-78524f79c4c7?q=80&w=800&auto=format&fit=crop',
    popular: false,
  },
  {
    id: 6,
    name: 'Karak Chai',
    description: 'Traditional Pakistani karak chai, creamy tea with foam, served hot.',
    price: 150,
    image: 'https://images.unsplash.com/photo-1561336313-0bd5e0b27ec8?q=80&w=800&auto=format&fit=crop',
    popular: false,
  },
];

export default function MenuHighlights() {
  const { addToCart } = useCart();

  return (
    <section id="menu" className="py-24 bg-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-5xl md:text-6xl font-black text-stone-900 uppercase tracking-tighter mb-4">
            Menu <span className="text-red-600">Highlights</span>
          </h2>
          <p className="text-stone-600 text-lg max-w-2xl mx-auto">
            Our most loved items, crafted with premium ingredients and packed with flavor.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-2xl overflow-hidden shadow-xl shadow-stone-200/50 group hover:-translate-y-2 transition-transform duration-300 flex flex-col"
            >
              <div className="relative h-64 overflow-hidden bg-stone-200 shrink-0">
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                {item.popular && (
                  <div className="absolute top-4 right-4 bg-red-600 text-white text-xs font-bold uppercase tracking-wider py-1 px-3 rounded-full shadow-lg">
                    Best Seller
                  </div>
                )}
              </div>
              <div className="p-6 flex flex-col flex-1">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-display text-2xl font-bold text-stone-900 uppercase leading-tight">
                    {item.name}
                  </h3>
                </div>
                <p className="text-stone-500 text-sm mb-6 line-clamp-2">
                  {item.description}
                </p>
                <div className="flex items-center justify-between mt-auto">
                  <span className="font-bold text-xl text-red-600">PKR {item.price}</span>
                  <button 
                    onClick={() => addToCart({ id: item.id, name: item.name, price: item.price, image: item.image })}
                    className="w-10 h-10 rounded-full bg-stone-100 flex items-center justify-center text-stone-900 hover:bg-red-600 hover:text-white transition-colors"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href="https://wa.me/9221111111622"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center bg-stone-900 hover:bg-stone-800 text-white px-8 py-4 rounded-full font-bold uppercase tracking-wider text-lg transition-transform hover:scale-105"
          >
            View Full Menu & Order
          </a>
        </div>
      </div>
    </section>
  );
}
