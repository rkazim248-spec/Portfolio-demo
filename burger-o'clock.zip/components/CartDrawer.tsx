'use client';

import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import Image from 'next/image';

export default function CartDrawer() {
  const { isCartOpen, setIsCartOpen, cartItems, updateQuantity, totalPrice } = useCart();

  const handleCheckout = () => {
    const text = `Hello Burger O'Clock! I'd like to order:\n\n${cartItems.map(item => `${item.quantity}x ${item.name} - PKR ${item.price * item.quantity}`).join('\n')}\n\n*Total: PKR ${totalPrice}*`;
    window.open(`https://wa.me/9221111111622?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-black/60 z-[60] backdrop-blur-sm"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full sm:w-[400px] bg-white z-[70] shadow-2xl flex flex-col"
          >
            <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-3">
                <ShoppingBag className="text-red-600" />
                <h2 className="font-display text-2xl font-bold uppercase tracking-wide">Your Cart</h2>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)} 
                className="p-2 hover:bg-stone-200 rounded-full transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-stone-400 space-y-4">
                  <ShoppingBag size={64} className="opacity-20" />
                  <p className="text-lg font-medium">Your cart is empty</p>
                  <button 
                    onClick={() => setIsCartOpen(false)} 
                    className="text-red-600 font-bold uppercase tracking-wider text-sm hover:underline"
                  >
                    Browse Menu
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {cartItems.map(item => (
                    <div key={item.id} className="flex gap-4 items-center">
                      <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-stone-100">
                        <Image 
                          src={item.image} 
                          alt={item.name} 
                          fill 
                          className="object-cover" 
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-stone-900 leading-tight mb-1">{item.name}</h4>
                        <p className="text-red-600 font-bold text-sm mb-2">PKR {item.price}</p>
                        <div className="flex items-center gap-3 bg-stone-100 w-fit rounded-full px-2 py-1">
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity - 1)} 
                            className="p-1 hover:bg-white rounded-full transition-colors"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="font-bold text-sm w-4 text-center">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity + 1)} 
                            className="p-1 hover:bg-white rounded-full transition-colors"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                      <div className="font-bold text-stone-900">
                        PKR {item.price * item.quantity}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cartItems.length > 0 && (
              <div className="p-6 border-t border-stone-100 bg-stone-50">
                <div className="flex justify-between items-center mb-6">
                  <span className="font-bold text-stone-500 uppercase tracking-wider">Total</span>
                  <span className="font-display text-3xl font-black text-stone-900">PKR {totalPrice}</span>
                </div>
                <button
                  onClick={handleCheckout}
                  className="w-full bg-red-600 hover:bg-red-700 text-white py-4 rounded-xl font-bold uppercase tracking-wider text-lg transition-transform hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-red-600/20"
                >
                  Checkout via WhatsApp
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
