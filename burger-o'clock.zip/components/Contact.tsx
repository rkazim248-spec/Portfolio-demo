import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-5xl md:text-6xl font-black text-stone-900 uppercase tracking-tighter mb-4">
            Find <span className="text-red-600">Us</span>
          </h2>
          <p className="text-stone-600 text-lg max-w-2xl mx-auto">
            Drop by for a quick bite or order online for delivery.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-stone-50 p-8 md:p-12 rounded-3xl"
          >
            <h3 className="font-display text-3xl font-bold uppercase mb-8 text-stone-900">Contact Information</h3>
            
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center shrink-0">
                  <MapPin className="text-red-600" size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 uppercase tracking-wider mb-1">Address</h4>
                  <p className="text-stone-600 leading-relaxed">
                    Plot 12-C, 26th Street, Tauheed Commercial Area,<br />
                    DHA Phase 5, Karachi, Sindh 75500,<br />
                    Pakistan
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center shrink-0">
                  <Phone className="text-red-600" size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 uppercase tracking-wider mb-1">Phone</h4>
                  <a href="tel:+9221111111622" className="text-stone-600 hover:text-red-600 transition-colors">
                    +92 21 111 111 622
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center shrink-0">
                  <Mail className="text-red-600" size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 uppercase tracking-wider mb-1">Email</h4>
                  <a href="mailto:info@burgeroclock.com" className="text-stone-600 hover:text-red-600 transition-colors">
                    info@burgeroclock.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center shrink-0">
                  <Clock className="text-red-600" size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 uppercase tracking-wider mb-1">Opening Hours</h4>
                  <ul className="text-stone-600 space-y-1">
                    <li><span className="font-medium">Mon – Thu:</span> 12:00 PM – 1:00 AM</li>
                    <li><span className="font-medium">Fri – Sun:</span> 12:00 PM – 2:00 AM</li>
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Map / Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-stone-900 p-8 md:p-12 rounded-3xl text-white flex flex-col"
          >
            <h3 className="font-display text-3xl font-bold uppercase mb-8">Send a Message</h3>
            
            <form className="flex-1 flex flex-col gap-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-bold uppercase tracking-wider text-stone-400 mb-2">Name</label>
                  <input type="text" id="name" className="w-full bg-stone-800 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors" placeholder="John Doe" />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-bold uppercase tracking-wider text-stone-400 mb-2">Phone</label>
                  <input type="tel" id="phone" className="w-full bg-stone-800 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors" placeholder="+92 300 0000000" />
                </div>
              </div>
              
              <div className="flex-1 flex flex-col">
                <label htmlFor="message" className="block text-sm font-bold uppercase tracking-wider text-stone-400 mb-2">Message</label>
                <textarea id="message" rows={4} className="w-full flex-1 bg-stone-800 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors resize-none" placeholder="How can we help you?"></textarea>
              </div>
              
              <button type="button" className="w-full bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-xl font-bold uppercase tracking-wider text-lg transition-transform hover:scale-[1.02] active:scale-[0.98]">
                Send Message
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
