import { motion } from 'motion/react';
import { Star } from 'lucide-react';

const reviews = [
  {
    id: 1,
    name: 'Ali Khan',
    rating: 5,
    text: 'Best Zinger burger in Karachi! The crunch and the sauce are just perfect. Highly recommended for late-night cravings.',
    date: '2 days ago',
  },
  {
    id: 2,
    name: 'Sara Ahmed',
    rating: 4,
    text: 'Loved the loaded fries and the beef cheese burger. The ambiance is great for hanging out with friends. Service was quick.',
    date: '1 week ago',
  },
  {
    id: 3,
    name: 'Usman Tariq',
    rating: 5,
    text: 'Burger O\'Clock never disappoints. The portions are huge and the prices are very reasonable. My go-to spot every weekend.',
    date: '3 weeks ago',
  },
];

export default function Reviews() {
  return (
    <section id="reviews" className="py-24 bg-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div>
            <h2 className="font-display text-5xl md:text-6xl font-black text-stone-900 uppercase tracking-tighter mb-4">
              Customer <span className="text-red-600">Reviews</span>
            </h2>
            <div className="flex items-center gap-4">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={24} className={i < 4 ? "fill-yellow-400 text-yellow-400" : "fill-yellow-400/30 text-yellow-400"} />
                ))}
              </div>
              <span className="text-2xl font-bold text-stone-900">4.4 / 5</span>
              <span className="text-stone-500 font-medium">Based on 2,000+ reviews</span>
            </div>
          </div>
          
          <a
            href="#"
            className="inline-flex items-center justify-center bg-white border-2 border-stone-200 hover:border-stone-900 text-stone-900 px-6 py-3 rounded-full font-bold uppercase tracking-wider text-sm transition-colors"
          >
            Leave a Review
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white p-8 rounded-2xl shadow-lg shadow-stone-200/50"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className={i < review.rating ? "fill-yellow-400 text-yellow-400" : "fill-stone-200 text-stone-200"} />
                ))}
              </div>
              <p className="text-stone-600 mb-6 italic">&quot;{review.text}&quot;</p>
              <div className="flex justify-between items-center border-t border-stone-100 pt-4">
                <span className="font-bold text-stone-900">{review.name}</span>
                <span className="text-sm text-stone-400">{review.date}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
