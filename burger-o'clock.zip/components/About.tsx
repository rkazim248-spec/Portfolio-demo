import { motion } from 'motion/react';
import Image from 'next/image';

export default function About() {
  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Image Grid */}
          <div className="lg:w-1/2 w-full">
            <div className="grid grid-cols-2 gap-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="space-y-4"
              >
                <div className="relative h-64 rounded-2xl overflow-hidden">
                  <Image
                    src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=800&auto=format&fit=crop"
                    alt="Making burgers"
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="relative h-48 rounded-2xl overflow-hidden">
                  <Image
                    src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=800&auto=format&fit=crop"
                    alt="Restaurant Vibe"
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="space-y-4 pt-12"
              >
                <div className="relative h-48 rounded-2xl overflow-hidden">
                  <Image
                    src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=800&auto=format&fit=crop"
                    alt="Crispy Fries"
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="relative h-64 rounded-2xl overflow-hidden bg-red-600 flex items-center justify-center p-6 text-center">
                  <div>
                    <span className="block font-display text-5xl font-black text-white mb-2">2000+</span>
                    <span className="block text-white/90 font-bold uppercase tracking-wider text-sm">Happy Customers</span>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Content */}
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-display text-5xl md:text-6xl font-black text-stone-900 uppercase tracking-tighter mb-6">
                The <span className="text-red-600">Burger O&apos;Clock</span> Story
              </h2>
              
              <div className="space-y-6 text-lg text-stone-600">
                <p>
                  A popular fast-food chain in Karachi known for its juicy burgers, crispy fried items, and quick service. We started with a simple mission: to serve the best burgers in town without compromising on quality or taste.
                </p>
                <p>
                  Whether you&apos;re a teenager looking for a quick bite after college, a family wanting a fun dinner out, or someone craving a late-night snack, Burger O&apos;Clock is your go-to spot.
                </p>
                <p>
                  We offer a casual, vibrant dine-in experience along with lightning-fast takeaway and delivery options. Our ingredients are sourced fresh daily, and every burger is made to order.
                </p>
              </div>

              <div className="mt-10 grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-stone-900 uppercase tracking-wider mb-2">Target Audience</h4>
                  <ul className="text-stone-600 space-y-1">
                    <li>• Teenagers & Students</li>
                    <li>• Fast Food Lovers</li>
                    <li>• Families</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 uppercase tracking-wider mb-2">Price Range</h4>
                  <p className="text-stone-600 font-medium text-xl">PKR 800 – 1,500</p>
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
