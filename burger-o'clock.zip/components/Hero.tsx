import { motion } from 'motion/react';
import Image from 'next/image';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[100svh] flex items-center justify-center overflow-hidden bg-black">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1920&auto=format&fit=crop"
          alt="Juicy Burger Background"
          fill
          className="object-cover opacity-50"
          priority
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex flex-col items-center"
        >
          <span className="inline-block py-1 px-3 rounded-full bg-red-600/20 border border-red-500/30 text-red-500 font-bold tracking-widest text-sm uppercase mb-6 backdrop-blur-sm">
            Karachi&apos;s Favorite Fast Food
          </span>
          
          <h1 className="font-display text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-black text-white uppercase tracking-tighter leading-[0.85] mb-6 drop-shadow-2xl">
            Bigger.<br />
            <span className="text-red-600">Juicier.</span><br />
            Better.
          </h1>
          
          <p className="max-w-2xl mx-auto text-lg sm:text-xl md:text-2xl text-stone-300 font-medium mb-10 drop-shadow-md">
            Experience the ultimate burger rush at Burger O&apos;Clock. 
            Late night cravings? We&apos;ve got you covered until 2 AM.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center w-full sm:w-auto">
            <a
              href="https://wa.me/9221111111622"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-full font-bold uppercase tracking-wider text-lg transition-transform hover:scale-105 active:scale-95 shadow-[0_0_40px_rgba(220,38,38,0.4)]"
            >
              Order Online
            </a>
            <a
              href="#menu"
              className="w-full sm:w-auto bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/20 px-8 py-4 rounded-full font-bold uppercase tracking-wider text-lg transition-all hover:scale-105 active:scale-95"
            >
              View Menu
            </a>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-white/50 text-xs uppercase tracking-widest font-bold">Scroll</span>
        <div className="w-[2px] h-12 bg-white/20 relative overflow-hidden">
          <motion.div 
            animate={{ y: [0, 48] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
            className="absolute top-0 left-0 w-full h-1/2 bg-red-600"
          />
        </div>
      </motion.div>
    </section>
  );
}
