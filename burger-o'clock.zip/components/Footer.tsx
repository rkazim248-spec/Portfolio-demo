import { Facebook, Instagram, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black text-white pt-20 pb-10 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                <span className="text-white font-display font-bold text-xl">B</span>
              </div>
              <span className="font-display font-bold text-2xl tracking-wide uppercase">
                Burger O&apos;Clock
              </span>
            </a>
            <p className="text-stone-400 mb-6">
              Bigger, Juicier, Better Burgers. Serving the best fast food in Karachi.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-red-600 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-red-600 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-red-600 transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold uppercase tracking-wider mb-6">Quick Links</h4>
            <ul className="space-y-3 text-stone-400">
              <li><a href="#home" className="hover:text-red-500 transition-colors">Home</a></li>
              <li><a href="#menu" className="hover:text-red-500 transition-colors">Menu</a></li>
              <li><a href="#deals" className="hover:text-red-500 transition-colors">Deals</a></li>
              <li><a href="#about" className="hover:text-red-500 transition-colors">About Us</a></li>
              <li><a href="#contact" className="hover:text-red-500 transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-bold uppercase tracking-wider mb-6">Legal</h4>
            <ul className="space-y-3 text-stone-400">
              <li><a href="#" className="hover:text-red-500 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-red-500 transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-red-500 transition-colors">Refund Policy</a></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-bold uppercase tracking-wider mb-6">Newsletter</h4>
            <p className="text-stone-400 mb-4">Subscribe to get special offers and updates.</p>
            <form className="flex gap-2">
              <input 
                type="email" 
                placeholder="Your email" 
                className="w-full bg-stone-900 border border-stone-800 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-red-500 transition-colors"
              />
              <button 
                type="button"
                className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg font-bold uppercase tracking-wider text-sm transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-stone-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Burger O&apos;Clock. All rights reserved.</p>
          <p>Designed for Karachi.</p>
        </div>
      </div>
    </footer>
  );
}
